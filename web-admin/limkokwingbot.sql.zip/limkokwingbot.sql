-- MySQL dump 10.13  Distrib 5.7.27, for Win64 (x86_64)
--
-- Host: localhost    Database: limkokwingbot
-- ------------------------------------------------------
-- Server version	5.7.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `salary` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'Amir Izzat Oh','Kampung Gajah Ohkay',1500);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty` (
  `faculty_id` int(5) NOT NULL AUTO_INCREMENT,
  `faculty_code` varchar(10) NOT NULL,
  `faculty_name` varchar(100) NOT NULL,
  PRIMARY KEY (`faculty_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
INSERT INTO `faculty` VALUES (1,'FFLC','Faculty of Fashion & Lifestyle Creativity'),(2,'FABE','Faculty of Architecture & The Built Environment'),(3,'FBMG','Faculty of Business Management & Globalization'),(4,'FCMB','Faculty of Communication, Media & Broadcasting'),(5,'FDI','Faculty of Design Innovation'),(6,'FICT','Faculty of Information & Communication Technology'),(7,'FMC','Faculty of Multimedia Creativity'),(8,'LSMDA','Limkokwing Sound & Music Design Academy'),(9,'PGC','Postgraduate Centre');
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `modules_id` int(11) NOT NULL AUTO_INCREMENT,
  `modules_code` varchar(10) NOT NULL,
  `modules_name` varchar(200) NOT NULL,
  `student_id` int(10) NOT NULL,
  PRIMARY KEY (`modules_id`),
  KEY `student_id` (`student_id`),
  KEY `modules_code` (`modules_code`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,'BIE1233','C++ Programming',0),(2,'BIL1112','Communication Theory & Study Skills',0),(3,'MPU3113','Ethnic Relations',0),(4,'BIE1113','Fundamental of Computer Systems',0),(5,'BIE1124','Mathematics for Computing',0),(6,'BIT1312','Multimedia Technology',0),(7,'BIL2222','Business Communication Skills',0),(8,'BIN1214','Data Communication',0),(9,'BIS1214','Database System',0),(10,'BIS1513','Intro to Information Systems',0),(11,'MPU3123','Islamic Civilisation and Asian Civilisation',0),(12,'BIE1213','Java Programming I',0),(13,'BIE1143','Probability & Statistics',0),(14,'BIT3273','Computer Network',0),(15,'MPU3222','Creative & Innovative Skills',0),(16,'BIE2153','Discrete Structures',0),(17,'BCC2213','Distributed System for Cloud Computing',0),(18,'BIE2223','Java Programming II',0),(19,'BIM2323','Mobile System',0),(20,'BIT2233','System Development Methods & Tools',0),(21,'BBIS3523','Business Intelligence Tools',0),(22,'BBIS2513','Data Warehousing',0),(23,'BIS2532','Information Technology Law',0),(24,'BBB3612','Knowledge Management',0),(25,'BIN2313','Network Design & Management',0),(26,'BIN2323','Wireless Internet Application',0),(27,'BIM3253','Wireless Network',0),(28,'MPU3342','Work Sociology and Malaysian Industry',0),(29,'BCC2223','Cloud Architecture',0),(30,'BCC3233','Cloud Application Development',0),(31,'MPU3422','Co-curricular',0),(32,'BIS3562','Ethics & Professional Conduct',0),(33,'BIN3343','High Speed Networks',0),(34,'UCC2146','Global Classroom',0),(35,'BIE3264','Major Project I',0),(36,'BIE3443','Software Project Management',0),(37,'BIT3342','Database Design & Management',0),(38,'BCC3313','Enterprise Storage System',0),(39,'BIE3274','Major Project II',0),(40,'BIT3413','Network Security & Testing',0),(41,'BIT3516','Practical Internship',0),(42,'BAS123','Accounting',0);
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_info`
--

DROP TABLE IF EXISTS `student_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_info` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `student_id` int(9) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `course_name` varchar(150) NOT NULL,
  `term` varchar(50) NOT NULL,
  `module_code_1` varchar(10) NOT NULL,
  `module_name_1` varchar(255) NOT NULL,
  `grade_1` varchar(2) NOT NULL,
  `module_code_2` varchar(10) NOT NULL,
  `module_name_2` varchar(255) NOT NULL,
  `grade_2` varchar(2) NOT NULL,
  `module_code_3` varchar(10) NOT NULL,
  `module_name_3` varchar(255) NOT NULL,
  `grade_3` varchar(2) NOT NULL,
  `module_code_4` varchar(10) NOT NULL,
  `module_name_4` varchar(255) NOT NULL,
  `grade_4` varchar(2) NOT NULL,
  `module_code_5` varchar(10) NOT NULL,
  `module_name_5` varchar(255) NOT NULL,
  `grade_5` varchar(2) NOT NULL,
  `module_code_6` varchar(10) NOT NULL,
  `module_name_6` varchar(255) NOT NULL,
  `grade_6` varchar(2) NOT NULL,
  `cgpa` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_info`
--

LOCK TABLES `student_info` WRITE;
/*!40000 ALTER TABLE `student_info` DISABLE KEYS */;
INSERT INTO `student_info` VALUES (1,110047905,'Amir Izzat bin Abdul Hamid','Bachelor of Computer Science with Cloud Computing Technology','6/2019','BIE1233','C++ Programming','A','BIL1112','Communication Theory & Study Skills','A','MPU3113','Ethnic Relationss','A','BIE1113','Fundamental of Computer Systems','A','BIE1124','Mathematics for Computing','A','BIT1312','Multimedia Technology','A+',3.99),(2,110047827,'Muhammad Amirul Najihin bin Zaidi','Bachelor in Information Technology','6/2019','BIE1231','C++ Programming','A+','','','','','','','','','','','','','','','',3.89),(3,110047988,'Nur Fariza binti Baharuddin','Bachelor of Computer Science with Cloud Computing Technology','6/2019','BAK123','Discussion','B-','A','A','A','A','B','B','B','C','C','C','D','D','D','E','E',2),(4,110045611,'Muhammad Shahmil Nadjmie bin Sulaiman','Bachelor of Accounting','5/2019','BIE1233','Discrete Structures','B+','','','','','','','','','','','','','','','',3.78),(5,110047815,'Muhammad Rasul','Mathematical Science','6/2019','N/A','Not Available','NA','N/A','Not Available','NA','N/A','Not Available','NA','N/A','Not Available','NA','N/A','Not Available','NA','N/A','Not Available','NA',3.12),(6,110047814,'Nurul Asyikin','Science Technology','6/2019','BIE1233','C++ Programming','A-','A','A','A','A','a','A','A','A','A','A','A','A','A','A','a',3);
/*!40000 ALTER TABLE `student_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2y$10$gCokufeXrm1AcV.A2HWc8O0ofOC/sOZU4.7S6F1dhemJLhS7LuUvK','2019-10-24 16:53:47'),(2,'user1','$2y$10$3yAkoSjA3hS6weHGXaxX8O6.R04zFdM0o3799zTHkcZ1vrEurWVl2','2019-10-28 01:14:43'),(3,'test2','$2y$10$sb8m6VcgixLuks75q1pd/OfetHSznU0.bJdBu6TPO9ldFhKhpBs8.','2019-10-29 11:10:15');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_step`
--

DROP TABLE IF EXISTS `users_step`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_step` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(1024) NOT NULL,
  `last_name` varchar(1024) DEFAULT NULL,
  `username` varchar(1024) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `step` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_step`
--

LOCK TABLES `users_step` WRITE;
/*!40000 ALTER TABLE `users_step` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_step` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'limkokwingbot'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-30 23:19:21
